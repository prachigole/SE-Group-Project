
function checkFirst() {
    var text = document.getElementById("lessthan").value;
    console.log(text);

    if (text <= 0) {
      alert ("Value cannot be lesser than 0!");
    }}