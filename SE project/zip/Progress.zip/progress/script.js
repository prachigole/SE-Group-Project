function increment(myInput) {
  myInput.value = (+myInput.value + 1) || 0;
}
function decrement(myInput) {
  // var a = myInput.value = (myInput.value - 1) || 0;

  var a = myInput.value;
  if(a>0)
  {
    myInput.value=myInput.value - 1;
  }
}

function checkFirst() {
    var text = document.getElementById("lessthan").value;
    console.log(text);
    if (text <= 0) {
      console.log("lessthan");
        text.value=0;   
    }
}